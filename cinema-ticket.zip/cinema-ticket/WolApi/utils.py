import random
import string
from django.core.cache import cache
from django.core.mail import send_mail
from django.conf import settings
from datetime import datetime
from .models import Ticket
import redis
import math


r = redis.Redis(host='127.0.0.1', port=6379, decode_responses=True)
OTP_EXPIRY_TIME = 300 
def generate_otp(user_id):
    if not user_id:
        raise ValueError("User ID can not be None")
    digit = str(random.randint(10000,99999))
    redis_key = f"HelloNavid"
    r.setex(redis_key,OTP_EXPIRY_TIME,digit)
    return digit

def validate_otp(keyy, otp):
    print(f"Key: {keyy}, OTP: {otp}")
    print(f"Key Type: {type(keyy)}, OTP Type: {type(otp)}")
    if not keyy or not otp:
        raise ValueError("Key or OTP is None")
    stored_key = r.get(keyy)
    if stored_key and stored_key == str(otp):
        r.delete(keyy)
        return True
    else:
        return False


def calculate_ticket_price(base_price, discount=0, tax_rate=0.1):
    discounted_price = base_price * (1 - discount)
    final_price = discounted_price * (1 + tax_rate)
    return round(final_price, 2)

def format_datetime(dt):
    return dt.strftime('%Y-%m-%d %H:%M:%S')

def is_seat_available(showtime, seat):
    return not Ticket.objects.filter(showtime=showtime, seat=seat).exists()

def send_ticket_confirmation(user_email, ticket_details):
    subject = 'تأیید خرید بلیط سینما'
    message = f"جزئیات بلیط شما:\n{ticket_details}"
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [user_email]
    send_mail(subject, message, email_from, recipient_list)
