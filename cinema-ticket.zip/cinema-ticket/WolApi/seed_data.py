from datetime import datetime, timedelta
from random import randint, choice
from django.utils import timezone
from .models import User, Role, Permission, Cinema, City, Province, Movie, Screening, Seat, Ticket, Review, Hall, Showtime, Reservation


provinces = ['Tehran', 'Isfahan', 'Shiraz', 'Mashhad', 'Tabriz']
province_objects = []
for province in provinces:
    province_objects.append(Province.objects.create(ProvinceName=province))


cities = [
    ('Tehran', 'Tehran'), 
    ('Isfahan', 'Isfahan'), 
    ('Shiraz', 'Fars'),
    ('Mashhad', 'Razavi Khorasan'),
    ('Tabriz', 'East Azerbaijan')
]
city_objects = []
for city, province_name in cities:
    province = Province.objects.get(ProvinceName=province_name)
    city_objects.append(City.objects.create(CityName=city, ProvinceID=province))


cinema_names = ['Cinema A', 'Cinema B', 'Cinema C', 'Cinema D', 'Cinema E']
cinema_objects = []
for cinema_name in cinema_names:
    city = choice(city_objects)
    cinema_objects.append(Cinema.objects.create(CinemaName=cinema_name, CityID=city, ProvinceID=city.ProvinceID, Address="Some Address"))


movies = [
    ('Movie A', 'Action', 120, '2024-01-01'),
    ('Movie B', 'Comedy', 90, '2024-02-01'),
    ('Movie C', 'Drama', 150, '2024-03-01'),
    ('Movie D', 'Horror', 100, '2024-04-01'),
    ('Movie E', 'Sci-Fi', 130, '2024-05-01')
]
movie_objects = []
for title, genre, duration, release_date in movies:
    movie_objects.append(Movie.objects.create(Title=title, Genre=genre, DurationMinutes=duration, ReleaseDate=release_date))


hall_objects = []
for cinema in cinema_objects:
    hall_objects.append(Hall.objects.create(cinema=cinema, name=f'Hall {cinema.CinemaName}', seat_count=100))


showtimes = []
for movie in movie_objects:
    hall = choice(hall_objects)
    showtimes.append(Showtime.objects.create(movie=movie, hall=hall, showtime=timezone.now() + timedelta(days=randint(1, 30))))


user_objects = []
for i in range(1, 11):
    user_objects.append(User.objects.create(
        email=f'user{i}@example.com',
        first_name=f'First{i}',
        last_name=f'Last{i}',
        phone_number=f'0912345678{i}',
        password='password123'
    ))


role_objects = []
for role_name in ['Admin', 'User', 'Manager']:
    role_objects.append(Role.objects.create(RoleName=role_name))


permission_objects = []
for permission in ['View Movies', 'Reserve Tickets', 'Manage Cinemas']:
    permission_objects.append(Permission.objects.create(Action=permission))


for role in role_objects:
    for permission in permission_objects:
        role.permissions.add(permission)

screening_objects = []
for cinema in cinema_objects:
    for movie in movie_objects:
        screening_objects.append(Screening.objects.create(
            AuditoriumID=randint(1, 10),
            MovieID=movie,
            CinemaID=cinema,
            StartTime=timezone.now() + timedelta(days=randint(1, 30)),
            EndTime=timezone.now() + timedelta(hours=2),
            Capacity=150
        ))

seat_objects = []
for screening in screening_objects:
    for i in range(1, 51):  # هر screening 50 صندلی
        seat_objects.append(Seat.objects.create(AuditoriumID=screening))


ticket_objects = []
for user in user_objects:
    for seat in seat_objects:
        ticket_objects.append(Ticket.objects.create(
            UserID=user,
            SeatID=seat,
            Price=randint(50000, 100000),
            PurchaseDateTime=timezone.now()
        ))


reservation_objects = []
for ticket in ticket_objects:
    cinema = choice(cinema_objects)
    reservation_objects.append(Reservation.objects.create(
        ticket=ticket,
        cinema=cinema,
        showtime=timezone.now() + timedelta(days=randint(1, 30))
    ))


review_objects = []
for movie in movie_objects:
    for user in user_objects:
        review_objects.append(Review.objects.create(
            UserID=user,
            MovieID=movie,
            Rating=randint(1, 5),
            ReviewText="This is a review text.",
            ReviewDate=timezone.now()
        ))

print("Data seeding complete!")
