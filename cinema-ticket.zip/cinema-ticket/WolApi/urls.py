from django.urls import path
from .views import MovieListView, BookTicketView,send_otp,authentication,my_view
from .views import RegisterUserView

urlpatterns = [
    path('movies/', MovieListView.as_view(), name='movie_list'),
    path('tickets/book/', BookTicketView.as_view(), name='book_ticket'),
    path('sendOTP/',send_otp,name='otp'),
    path('validation/',authentication,name='otp'),
    path('debug/', my_view, name='debug_view'),
    path('register/', RegisterUserView.as_view(), name='register_user'),
]
