from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Movie,Showtime, Seat, Ticket, Role 
from .serializers import MovieSerializer
from rest_framework.permissions import IsAuthenticated
from django.core.mail import send_mail
from .utils import generate_otp, validate_otp
from rest_framework_simplejwt.tokens import RefreshToken
from django.http import JsonResponse
from WolApi.models import User

class RegisterUserView(APIView):
    def post(self, request):
        roleId = request.data.get('RoleId')
        name = request.data.get('Name')
        familyName = request.data.get('FamilyName')
        birthDate = request.data.get('BirthDate')
        phoneNumber = request.data.get('PhoneNumber')
        email = request.data.get('Email')
        password = request.data.get('Password')
        print(roleId, name, familyName, birthDate, phoneNumber, email, password)

        try:
            role = Role.objects.get(id=roleId) 
            print(role)
        except Role.DoesNotExist:
            return Response({'Error': 'Invalid Role ID'}, status=status.HTTP_400_BAD_REQUEST)


        if not (roleId and name and familyName and birthDate and phoneNumber and email and password):
            return Response({'Error': 'Error has occurred because you have not filled some parts'}, status=status.HTTP_400_BAD_REQUEST)


        if User.objects.filter(email=email).exists():
            return Response({'Error': 'This email already exists'}, status=status.HTTP_400_BAD_REQUEST)


        if User.objects.filter(phone_number=phoneNumber).exists():
            return Response({'Error': 'This phone number already exists'}, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects.create(
            email=email,
            first_name=name,
            last_name=familyName,
            phone_number=phoneNumber
        )
        user.set_password(password)  # Hash the password
        user.save()

        refresh = RefreshToken.for_user(user)

        return Response({
            'message': 'User registered successfully.',
            'user': {
                'id': user.id,
                'email': user.email,
                'phone_number': phoneNumber,
                'name': user.first_name,
                'family_name': user.last_name,
            },
            'tokens': {
                'access': str(refresh.access_token),
                'refresh': str(refresh)
            }
        }, status=status.HTTP_201_CREATED)

class MovieListView(APIView):
    def get(self, request):
        movies = Movie.objects.all()
        serializer = MovieSerializer(movies, many=True)
        return Response(serializer.data)


class BookTicketView(APIView):
    def post(self, request):
        user_id = request.data.get('user_id')
        showtime_id = request.data.get('showtime_id')
        seat_id = request.data.get('seat_id')

        try:
            user = User.objects.get(id=user_id)
            showtime = Showtime.objects.get(id=showtime_id)
            seat = Seat.objects.get(id=seat_id)

            if Ticket.objects.filter(showtime=showtime, seat=seat).exists():
                return Response({"error": "This seat is already booked."}, status=status.HTTP_400_BAD_REQUEST)




            ticket = Ticket.objects.create(showtime=showtime, seat=seat, user=user, price=100)

            return Response({"message": "Ticket booked successfully", "ticket_id": ticket.id}, status=status.HTTP_201_CREATED)

        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
        except Showtime.DoesNotExist:
            return Response({"error": "Showtime not found"}, status=status.HTTP_404_NOT_FOUND)
        except Seat.DoesNotExist:
            return Response({"error": "Seat not found"}, status=status.HTTP_404_NOT_FOUND)
        
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.exceptions import AuthenticationFailed

@api_view(['POST'])
def send_otp(request):
    
   
    try:
        user, _ = JWTAuthentication().authenticate(request)
    except AuthenticationFailed:
        return Response({"error": "Authentication required"}, status=status.HTTP_401_UNAUTHORIZED)

    if not user.id:
        return Response({"error": "User ID is missing"}, status=status.HTTP_400_BAD_REQUEST)

    otp = generate_otp(user.id)
    try:
        send_mail(
            subject="Your OTP Code",
            message=f"Your OTP code is: {otp}",
            from_email="noreply@yourapp.com",
            recipient_list=[user.email],
        )
    except Exception as e:
        return Response({"error": "Failed to send email", "details": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    return Response({"message": "OTP sent successfully"}, status=status.HTTP_200_OK)

@api_view(['POST'])
def authentication(request):
    otp = request.data.get('otp')
    print(f"Received OTP: {otp}")
    
    
    if  not request.user.id:
        return Response({"error": "User ID not found"}, status=status.HTTP_400_BAD_REQUEST)
    
   
    if not otp:
        return Response({"error": "OTP not provided"}, status=status.HTTP_400_BAD_REQUEST)
    
    
    if validate_otp(request.user.id, otp):
        return Response({"message": "OTP verified successfully"}, status=status.HTTP_200_OK)
    else:
        return Response({"error": "Invalid or expired OTP"}, status=status.HTTP_400_BAD_REQUEST)


def my_view(request):
    print("Request Method:", request.method)
    print("Request Headers:", request.headers)
    print("GET Params:", request.GET)
    print("POST Params:", request.POST) 
    print("Request Body:", request.body)  

    return JsonResponse({'message': 'Debugging Request Data'})
